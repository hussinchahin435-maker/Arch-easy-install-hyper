#!/bin/bash

# مسار المستودع الأساسي
REPO_RAW="https://raw.githubusercontent.com/hussinchahin435-maker/NeoAnime-Hypr/main"

# التأكد من وجود Zenity
if ! command -v zenity &> /dev/null; then sudo pacman -S --noconfirm zenity; fi

# اختيار القرص
select_disk() {
    local disks=$(lsblk -dpn -o NAME,SIZE | grep -v 'loop' | awk '{print $1, $2}')
    local selection=$(zenity --list --title="Disk Selection" \
        --text="Select the target disk (All data will be erased):" \
        --column="Disk" --column="Size" $disks --width=400 --height=300)
    [ -z "$selection" ] && exit 1
    echo "$selection"
}

TARGET_DISK=$(select_disk)

# عملية التثبيت
(
    echo "10"; echo "# Creating directories..."
    mkdir -p ~/.config/hypr ~/.config/waybar
    
    echo "40"; echo "# Downloading configurations..."
    curl -s -L -o ~/.config/hypr/hyprland.conf "$REPO_RAW/configs/hypr/hyprland.conf"
    curl -s -L -o ~/.config/waybar/config "$REPO_RAW/configs/waybar/config.json"
    curl -s -L -o ~/.config/waybar/style.css "$REPO_RAW/configs/waybar/style.css"
    
    echo "80"; echo "# Installing packages..."
    sudo pacman -S --noconfirm waybar hyprland rofi swww wlogout
    
    echo "100"; echo "# Done!"
) | zenity --progress --title="Installing NeoAnime-Hypr" --percentage=0 --auto-close --width=400

zenity --info --title="Setup Complete" --text="Installation successful! Reboot recommended." --width=400
